registered_players = [
  {
    id: 1,
    username: "andre",
    password: "andre123",
    total_wins: 5,
  },

  {
    id: 2,
    username: "utsav",
    password: "utsav123",
    total_wins: 3,
  },

  {
    id: 3,
    username: "virag",
    password: "virag123",
    total_wins: 4,
  },

  // Will get more players from the form
];
